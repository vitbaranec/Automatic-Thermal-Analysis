#' @export
#' 
areasphere<-function(radius){
  Area <- 4*pi*radius^2
  Area
}

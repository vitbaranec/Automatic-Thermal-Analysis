#' @export
#' 
StephBoltz<-function(){
  s<-5.670e-8
  # Stephan-Boltzman Constant Units: W/m^2/K^4 
  s}

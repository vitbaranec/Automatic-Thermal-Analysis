#' @export
#' 
rotate90.matrix <-
function(x) {
  t(mirror.matrix(x))
}
